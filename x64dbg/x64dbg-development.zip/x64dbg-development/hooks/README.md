# hooks

This contains two binaries `AStyleWhore.exe` and `AStyle.dll` to format any code before you commit. They are signed with the serial number `‎37 ba b6 0f 84 53 0e 5e e5 76 ba d2 6d 45 4b 58`.

If you are unsure about the integrity of the files, don't hesitate to contact me (mrexodia). The source code is available at [BitBucket](https://bitbucket.org/mrexodia/astylewhore). The version of `AStyle.dll` is compiled from `AStyle_2.06_windows.zip` which came from [Sourceforge](https://sourceforge.net/projects/astyle/files/astyle/astyle%202.06/AStyle_2.06_windows.zip/download).