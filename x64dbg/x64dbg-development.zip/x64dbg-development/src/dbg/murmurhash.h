//-----------------------------------------------------------------------------
// MurmurHash3 was written by Austin Appleby, and is placed in the public
// domain. The author hereby disclaims copyright to this source code.

#ifndef _MURMURHASH3_H_
#define _MURMURHASH3_H_

//-----------------------------------------------------------------------------
// Platform-specific functions and macros

// Microsoft Visual Studio

#if defined(_MSC_VER) && (_MSC_VER < 1600)

typedef unsigned char uint8_t;
typedef unsigned int uint32_t;
typedef unsigned __int64 uint64_t;

// Other compilers

#else    // defined(_MSC_VER)

#include <stdint.h>

#endif // !defined(_MSC_VER)

//-----------------------------------------------------------------------------

void MurmurHash3_x86_32(const void* key, int len, uint32_t seed, void* out);

void MurmurHash3_x86_128(const void* key, int len, uint32_t seed, void* out);

void MurmurHash3_x64_128(const void* key, int len, uint32_t seed, void* out);

//-----------------------------------------------------------------------------

#ifdef _WIN64
static inline
unsigned long long murmurhash(const void* data, int len)
{
    unsigned long long hash[2];
    MurmurHash3_x64_128(data, len, 0x1337, hash);
#else //x86
static inline
unsigned long murmurhash(const void* data, int len)
{
    unsigned int hash[1];
    MurmurHash3_x86_32(data, len, 0x1337, hash);
#endif //_WIN64
    return hash[0];
}

#endif // _MURMURHASH3_H_
