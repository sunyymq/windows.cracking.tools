#pragma once

#include "_global.h"

void Analyse_nukem(duint base, duint size);