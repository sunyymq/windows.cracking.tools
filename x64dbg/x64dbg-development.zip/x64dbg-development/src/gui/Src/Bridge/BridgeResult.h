#ifndef BRIDGERESULT_H
#define BRIDGERESULT_H

#include "Imports.h"

class BridgeResult
{
public:
    BridgeResult();
    ~BridgeResult();
    dsint Wait();
};

#endif // BRIDGERESULT_H
